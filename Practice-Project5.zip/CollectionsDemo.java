package com.collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;
import java.util.Stack;
import java.util.Vector;

public class CollectionsDemo {
public static void main(String[] args) {
	/*
	 	Collections
	 		1.List
	 			1.1.ArrayList
	 			1.2.LinkedList
	 			1.3.Vector
	 				1.3.1.Stack
	 		2.Set
	 			2.1.HashSet
	 				2.1.1.LinkedList
	 			2.2.SortedSet
	 				2.2.1.NavigableSet
	 					2.2.1.1.TreeSet
	 			
	 		3.Queue
	  
	 */
	Scanner s = new Scanner(System.in);
	ArrayList<Integer> al = new ArrayList<Integer>();
	//adding objects into ArrayList
	for(int i=0;i<5;i++)
	{
		System.out.println("Enter the "+(i+1)+" Element");
		al.add(s.nextInt());
	}
	//Reading objects from ArrayList
	for(Integer i:al)
	{
		int i1 =(Integer)i;
		System.out.print(i1+" ");
	}
	al.add(52);
	if(al.contains(52))
	{
		al.remove(2);
		System.out.println("Removed Successfully");
	}
	
	System.out.println();
	//using Iterator cursor
	Iterator itr =al.iterator();
	while(itr.hasNext())
	{
		System.out.println(itr.next());
	}
	System.out.println("Array list");
	
	//Linked List
	
	LinkedList<Integer> li = new LinkedList<Integer>();
	for(int i = 0;i<5;i++)
	{
		li.add(s.nextInt());
	}
	System.out.println("Added Successfully");
	Iterator itr1=li.listIterator();
	while(itr1.hasNext())
	{
		System.out.println(itr1.next());
	}
	li.addFirst(56);
	li.addLast(85);
	li.getLast();
	System.out.println("Linked List ");
	//Vector Demo
	Vector<Integer> v = new Vector<Integer>();
	v.add(52);
	v.add(85);
	v.add(85);
	System.out.println("Size : "+v.size());
	System.out.println("Capacity : "+v.capacity());
	for(int i=1;i<15;i++)
	{
		v.add(i);
	}
	System.out.println("Size : "+v.size());
	System.out.println("Capacity : "+v.capacity());
	v.remove(8);
	System.out.println("Size : "+v.size());
	System.out.println("Capacity : "+v.capacity());
	System.out.println(v.firstElement());
	System.out.println(v.lastElement());
	System.out.println("Vector");
	//Stack Demo
	Stack<Integer> st = new Stack<Integer>();
	st.add(85);
	st.add(52);
	st.add(58);
	System.out.println("Size : "+st.size());
	
	System.out.println(st.peek());
	System.out.println(st.pop());
	System.out.println("Size : "+st.size());
	st.push(25);
	st.push(85);
	st.push(95);
	System.out.println("Size : "+st.size());
	s.close();

}
}
