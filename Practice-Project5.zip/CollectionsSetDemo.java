package com.collections;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class CollectionsSetDemo {
public static void main(String[] args) {
	//sets Demo Adding characters to hash set
	HashSet<Character> s = new HashSet<Character>();
	for(int i=65;i<100;i++)
	{
		char c =(char)i;
		s.add(c);
	}
	Iterator<Character> itr = s.iterator();
	while(itr.hasNext())
	{
		System.out.print(itr.next()+" ");
	}
	System.out.println();
	
	//LinkedHashSet Demo
	LinkedHashSet<Integer> li = new LinkedHashSet<Integer>();
	li.add(10);
	li.add(30);
	li.add(40);
	System.out.println(li);
	li.remove(40);
	System.out.println(li);
	System.out.println("Size "+li.size());
	
	//TreeSet Demo
	TreeSet<String> ts = new TreeSet<String>();
	ts.add("Ameerpet");
	ts.add("Amalapuram");
	ts.add("AAA");
	ts.add("Begumpet");
	ts.add("KPHB");
	System.out.println(ts);
	ts.remove("KPHB");
	System.out.println(ts);
	
	
}
}
