package testing1;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class FileUpload {
  @Test
  public void f() throws InterruptedException, IOException {
	  
	  WebDriver driver = new ChromeDriver();
	  driver.get("https://www.naukri.com/registration/createAccount?othersrcp=22636");
	  
	  WebElement element = driver.findElement(By.xpath("//*[@id=\"root\"]/div/div/div[2]/div/div/div[1]/form/div[2]/div[5]/div[1]/div[1]/button"));

		element.click();		
		Thread.sleep(5000);
		
		Runtime.getRuntime().exec("D:\\upload.exe");
	  
	  
	  
	  
	  
	  
	  
	  
  }
}
