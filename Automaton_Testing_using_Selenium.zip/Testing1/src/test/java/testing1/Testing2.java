package testing1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Testing2 {
  @Test
  public void getConnection() throws Exception{
	  
	  WebDriver driver = new ChromeDriver();
	  driver.get("https://profile.oracle.com/myprofile/account/create-account.jspx");
	  Thread.sleep(2000);
	  
	  
	  WebElement email = driver.findElement(By.cssSelector("input#sView1\\:r1\\:0\\:email\\:\\:content"));
	  email.sendKeys("abc@gmail.com");
	  
	  
	  WebElement password =driver.findElement(By.xpath("//*[@id=\"sView1:r1:0:password::content\"]"));
	  password.sendKeys("abc@123");
	  
	  
	  
	  
	  
	  
	  
	  
  }
}
