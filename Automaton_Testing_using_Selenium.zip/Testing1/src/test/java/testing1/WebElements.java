package testing1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class WebElements {
  @Test
  public void inputField() throws Exception {
	  
	  
	  //input fields
	  
	  WebDriver driver = new ChromeDriver();
	  driver.get("https://www.amazon.in/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2Fs%3Fk%3Dflipkart%26adgrpid%3D1326012633048780%26hvadid%3D82876055231412%26hvbmt%3Dbe%26hvdev%3Dc%26hvlocphy%3D156428%26hvnetw%3Do%26hvqmt%3De%26hvtargid%3Dkwd-82876681051014%253Aloc-90%26hydadcr%3D15412_2338239%26tag%3Dmsndeskstdin-21%26ref%3Dnav_custrec_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0");
	  //checking wheather field is enabled or not
	  WebElement emailCheck = driver.findElement(By.xpath("//*[@id=\"ap_email\"]"));
	  Boolean status = emailCheck.isEnabled();
	  System.out.println(status);
	  //getting the input filed by id
	  WebElement email = driver.findElement(By.xpath("//*[@id=\"ap_email\"]"));
	  //sending the value
	  email.sendKeys("abc@gmail.com");
	  Thread.sleep(2000);
	  
	  //check wheather input box is present or not
	  
	  String email1=email.getText();
	  if(email1!="")
	  {
		  System.out.println("input filed is present");
	  }
	  //getting value from input field
	  String text = driver.findElement(By.xpath("//*[@id=\"ap_email\"]")).getAttribute("value");
	  System.out.println(text);
	  //clearing the value
	  email.clear();
	  driver.quit(); 
  }
  
  @Test
  public void linkOperations () throws InterruptedException
  {
	  
	  
	  WebDriver driver = new ChromeDriver();
	  driver.get("https://www.flipkart.com/");
	  WebElement link = driver.findElement(By.xpath("/html/body/div[3]/div/div/div/div[2]/div/form/div[4]/a"));
	  Thread.sleep(2000);
	  
	  //Get the link name
	  String value=link.getText();
	  System.out.println(value);
	  
		//Checking the status
	  Boolean status = link.isEnabled();
	  System.out.println(status);
	  
	  //click the link
	  link.click();


	  
	  //close
	  driver.quit();
	  
  }
  @Test
  public void button()
  {
	  WebDriver driver = new ChromeDriver();
	  driver.get("https://www.amazon.in/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2Fs%3Fk%3Dflipkart%26adgrpid%3D1326012633048780%26hvadid%3D82876055231412%26hvbmt%3Dbe%26hvdev%3Dc%26hvlocphy%3D156428%26hvnetw%3Do%26hvqmt%3De%26hvtargid%3Dkwd-82876681051014%253Aloc-90%26hydadcr%3D15412_2338239%26tag%3Dmsndeskstdin-21%26ref%3Dnav_custrec_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0");
	  
	  WebElement amazon = driver.findElement(By.id("ap_email"));
	  amazon.sendKeys("abc@gmail.com");
	  WebElement button = driver.findElement(By.id("continue"));
	  //checking status
	 Boolean status = button.isEnabled();
	 if(status)
	 System.out.println("Button is Enabled");
	 else
	 System.out.println("Button is Disabled");
	 
	 //clicking  
	  button.click();
	  //quite
	  driver.quit();
  }
  @Test
  public void imageOperations()
  {
	  WebDriver driver = new ChromeDriver();
	  driver.get("http://127.0.0.1:5500/ImageWebComponent/index.html");
	  //getting control of image
	  WebElement image = driver.findElement(By.xpath("/html/body/a"));
	  image.click();
  }
  @Test
  public void textArea()
  {
	  WebDriver driver = new ChromeDriver();
	  driver.get("http://127.0.0.1:5500/ImageWebComponent/index.html");
	  WebElement text =driver.findElement(By.xpath("//*[@id=\"area\"]"));
	  text.sendKeys("My self Rasheed ");
	
  }
  @Test
  public void checkboxes() throws Exception
  {
	  WebDriver driver = new ChromeDriver();
	  driver.get("http://127.0.0.1:5500/ImageWebComponent/index.html");
	  WebElement text =driver.findElement(By.xpath("/html/body/input[1]"));
	  Boolean status = text.isEnabled();
	  if(status)
		  System.out.println("Enabled");
	  else
		  System.out.println("Disabled");
	  Boolean enabledStatus = text.isSelected();
	  if(enabledStatus)
		  System.out.println("Selected");
	  else
		  System.out.println("Not Selected");
	  Thread.sleep(2000);
	  text.click();
	  Boolean enabledStatus1 = text.isSelected();
	  if(enabledStatus1)
		  System.out.println("Selected");
	  else
		  System.out.println("Not Selected");
	  System.out.println(text.getAttribute("value"));
	  
	  driver.close();
  }
  
  @Test
  public void radioButtons() throws Exception
  {
	  WebDriver driver = new ChromeDriver();
	  driver.get("http://127.0.0.1:5500/ImageWebComponent/index.html");
	  WebElement text =driver.findElement(By.xpath("//*[@id=\"gender\"]"));
	  Boolean status = text.isEnabled();
	  if(status)
		  System.out.println("Enabled");
	  else
		  System.out.println("Disabled");
	  Boolean enabledStatus = text.isSelected();
	  if(enabledStatus)
		  System.out.println("Selected");
	  else
		  System.out.println("Not Selected");
	  Thread.sleep(2000);
	  text.click();
	  Boolean enabledStatus1 = text.isSelected();
	  if(enabledStatus1)
		  System.out.println("Selected");
	  else
		  System.out.println("Not Selected");
	  System.out.println(text.getAttribute("value"));
	  
	  driver.close();
	  
  }
  
  
}
