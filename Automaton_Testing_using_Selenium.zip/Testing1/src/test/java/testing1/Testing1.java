package testing1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Testing1 {
	
	@Test
	public void getConnection()
	{
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.com/");
		System.out.println(driver.getTitle());
		System.out.println(driver.getTitle().length());
		
		
		  WebElement search = driver.findElement(By.xpath("//*[@id=\"APjFqb\"]"));
		  search.sendKeys("https://www.facebook.com/",Keys.ENTER);
		  
		  WebElement link = driver.findElement(By.xpath(
		  "//*[@id=\"rso\"]/div[1]/div/div/div/div/div/div/div/div[1]/div/span/a/div/div/div/cite"
		  )); link.click();
		  
		  WebElement name= driver.findElement(By.name("email"));
		  name.sendKeys("abdul@gmail.com");
		  
		  WebElement password = driver.findElement(By.name("pass"));
		  password.sendKeys("abdul@123");
		  
		 String s = driver.findElement(By.name("email")).getAttribute("placeholder");
		 System.out.println(s);
		 
		 
		 WebElement button = driver.findElement(By.name("login"));
		 button.click();
		 	
		
		//driver.navigate().to("https://www.facebook.com/");
		
		
	}
}
