package testing1;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;
import org.testng.annotations.Test;

public class ScreenShots {
  @Test
  public void f() {
	  
	  WebDriver driver = new ChromeDriver();
	  driver.get("https://www.google.com/");
	  
	  TakesScreenshot screenShot = (TakesScreenshot)driver;
	  File f =screenShot.getScreenshotAs(OutputType.FILE);
		
		try {
			FileHandler.copy(f, new File("C:\\Users\\abdul\\OneDrive\\Pictures\\Screenshots\\image3.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		driver.close();
	  
	  
	  
	  
  }
}
