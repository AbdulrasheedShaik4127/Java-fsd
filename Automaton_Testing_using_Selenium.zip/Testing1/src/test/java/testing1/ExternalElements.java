package testing1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class ExternalElements {
	@Test
	  public void externalElements() throws Exception
	  {
		  WebDriver driver = new ChromeDriver();
		  //alert box
		  driver.get("https://nxtgenaiacademy.com/alertandpopup/");
		  Thread.sleep(1000);
		  driver.findElement(By.name("alertbox")).click();
		  driver.switchTo().alert().accept();
		  
		  //confirm box
		  driver.findElement(By.name("confirmalertbox")).click();
		  Thread.sleep(1000);
		  //accepting
		  driver.switchTo().alert().accept();
		  //dismiss
		  //driver.switchTo().alert().dismiss();
		  
		  //prompt 
		  driver.findElement(By.name("promptalertbox1234")).click();
		  Thread.sleep(1000);
		  Thread.sleep(1000);
		  driver.switchTo().alert().sendKeys("No");
		  Thread.sleep(2000);
		  driver.switchTo().alert().accept();
		  
	  }
	
	
	@Test
	public void newTabs() throws Exception
	{
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.com/");
		
		driver.switchTo().newWindow(WindowType.TAB);
		//driver.switchTo().newWindow(WindowType.WINDOW);
		Thread.sleep(3000);
		Set<String> list=driver.getWindowHandles();
		Iterator<String> r =list.iterator();
		List<String> win = new ArrayList<String>();
		while(r.hasNext())
		{
			win.add(r.next());
		}
		driver.switchTo().window(win.get(0));
	}
}
