package com.multithreading;

import java.util.Scanner;

public class TryCatchDemo {
	static TryCatchDemo d = new TryCatchDemo();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter num1 :");
		int num1 = s.nextInt();
		System.out.println("Enter num2 :");
		int num2=s.nextInt();
		  try 
		  { 
			  int res = num1 / num2;
			  System.out.println(res); 
			  }
		  catch (ArithmeticException e) {
		  // TODO Auto-generated catch block
//		  System.out.println(e.getMessage());
//		  System.err.println(e);
//		  e.printStackTrace();
			  System.out.println("num2 should not be Zero");
		  }
		 
		 try {
			System.out.println(d.hashCode());
		} catch (NullPointerException e) {
			// TODO Auto-generated catch block
			System.out.println("Operations Cannot be done on null objects");
		}
		
	s.close();	
	}

}
