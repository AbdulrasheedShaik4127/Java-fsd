package com.multithreading;

import java.util.InputMismatchException;
import java.util.Scanner;

public class ExceptionHandlingDemo {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	
		System.out.println("Enter the name");
		String name=s.nextLine();
		System.out.println(name.length());
		System.out.println(name.toUpperCase());
		char[] a=name.toCharArray();
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
		}
	try(s;)//try with resource
	{
		System.out.println("SubString");
		System.out.println("Enter the sarting index");
		int first = s.nextInt();
		System.out.println("Enter the ending index");
		int ending = s.nextInt();
		String subString =name.substring(first, ending);
		System.out.println("Substring is "+subString);
	}catch(InputMismatchException  e)
	{
		System.out.println("Index values nust be Integers");
	}catch(NullPointerException e)
	{
		System.out.println("Please enter a value");
	}
	
}
}
