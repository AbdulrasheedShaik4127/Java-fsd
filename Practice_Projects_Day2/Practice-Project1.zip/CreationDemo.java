package com.multithreading;

public class CreationDemo extends Thread{
	/* we can define thread in two ways 
	 * 1.by extending Thread class
	 * 2.by implementing Runnable Interface
	 * */
	public void run()
	{
		for(int i=0;i<5;i++)
		{
				System.out.println("Thread of :"+i);
				
			
		}
	}
	public static void main(String[] args) {
		CreationDemo t1 = new CreationDemo();
		t1.start();
		
		
		
	}
	

}
