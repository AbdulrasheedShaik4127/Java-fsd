package com.multithreading;

public class CreationDemo1 implements Runnable {
	public void run()
	{
		for(int i=0;i<5;i++)
		{
			System.out.println("Creating Thread :"+(i+1));
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CreationDemo1 de = new CreationDemo1();
		Thread t =new Thread(de);
		t.start();

	}

}
