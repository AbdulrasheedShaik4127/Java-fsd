package com.multithreading;

import java.util.Scanner;

class MyException extends Exception
{
	public MyException(String msg)
	{
		super(msg);
	}
}
public class CustomExceptionsDemo {

	@SuppressWarnings("resource")
	public static void main(String[] args) throws MyException {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		System.out.println("Enter your age");
		int age = s.nextInt();
		try
		{
			if(age == 0)
			{
				throw new MyException("Age should not be zero");
			}
			else if(age < 18 && age !=0)
			{
				throw new MyException("Too Young...!!! not eligible");
			}
			else if(age >= 80)
			{
				throw new MyException("Too old...!!! not eligible");
			}
			else
			{
				System.out.println("Hurray...!! You are eligible");
			}
		}catch(MyException e)
		{
			System.out.println(e.getMessage());;
		}finally
		{
			System.out.println("Completed");
		}
		
		s.close();
	}

}
