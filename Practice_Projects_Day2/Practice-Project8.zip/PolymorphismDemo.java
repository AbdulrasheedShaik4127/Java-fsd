package com.oops;
class Polymorphism
{
	//overloading
	public void add(int a,int b)
	{
		System.out.println("Addition of two numbers :"+(a+b));
	}
	public void add(int a,int b,int c)
	{
		System.out.println("Addition of Three numbers :"+(a+b+c));
	}
	public void add(int a,int b,int c,int d)
	{
		System.out.println("Addition of Four numbers :"+(a+b+c+d));
	}
	
}
class Demo1 extends Polymorphism
{
	//overriding
	public void add(int a,int b)
	{
		System.out.println("From child class");
	}
	
	public void add(int a,int b,int c,int d,int e)
	{
		System.out.println("Addition of Four numbers :"+(a+b+c+d+e));
	}
}
public class PolymorphismDemo {
public static void main(String[] args) {
	Polymorphism p = new Polymorphism();
	Demo1 d = new Demo1();
	Polymorphism p1 = new Demo1();
	p.add(20, 30);
	p1.add(10, 20);
	p.add(10, 20);
	p.add(10, 20,30);
	p.add(10, 20,30,40);
}
}
