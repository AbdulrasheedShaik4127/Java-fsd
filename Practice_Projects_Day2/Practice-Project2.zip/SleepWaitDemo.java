package com.multithreading;

public class SleepWaitDemo implements Runnable {
	
	public void run()
	{
		synchronized(this)
		{
			this.notify();
		
		for(int i=65;i<80;i++)
		{
			
			char c= (char)i;
			System.out.print(c+" ");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SleepWaitDemo swd = new SleepWaitDemo();
		Thread t = new Thread(swd);
		t.start();
		synchronized(t)
		{
			try {
				t.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		for(int i=1;i<10;i++)
		{
			System.out.print(i+" ");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
	}

}
