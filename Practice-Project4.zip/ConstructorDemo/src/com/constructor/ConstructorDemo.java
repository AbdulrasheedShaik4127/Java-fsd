package com.constructor;

public class ConstructorDemo {
	/*
	 Constructor:-Constructor name is same as Class name without any
	 			  return type and constructor is used for Initialization
	 			  of variables
	 */
	String fname,lname,e_mail;
	public ConstructorDemo(String fname,String lname,String e_mail)
	{
		System.out.println("Parameterized Constructor");
		this.fname=fname;
		this.lname=lname;
		this.e_mail=e_mail;
	}
	public ConstructorDemo()
	{
		System.out.println("Non-Parameterized/default Constructor");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ConstructorDemo ad = new ConstructorDemo("kiran","gowra","gowra@gmail.com");
		ConstructorDemo ad1 =new ConstructorDemo();

	}

}
