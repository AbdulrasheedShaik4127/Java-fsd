package com.test;

import java.util.Arrays;
import java.util.Collection;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.TestFactory;

@DisplayName("JUnit 5 Dynamic Tests Example")
public class DynamicTest {
@TestFactory
Collection<DynamicTest> dynamicTests() {
	
    return Arrays.asList(
    	dynamicTest("simple dynamic test", () -> assertTrue(true)),
        dynamicTest("My Executable Class", new ExecutableImp()),
        dynamicTest("Exception Executable", () -> {throw new Exception("Exception Example");}),
        dynamicTest("simple dynamic test-2", () -> assertTrue(true))
    );
}

}
