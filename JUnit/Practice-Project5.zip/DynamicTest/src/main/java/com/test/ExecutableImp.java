package com.test;

import org.junit.jupiter.api.function.Executable;

public class ExecutableImp implements Executable {

	@Override
	public void execute() throws Throwable {
        System.out.println("Hello World!");

	}

}
