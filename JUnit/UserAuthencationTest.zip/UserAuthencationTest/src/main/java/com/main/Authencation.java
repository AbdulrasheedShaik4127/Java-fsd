package com.main;

public class Authencation {
	
	public String userCheck(String userName,String Password)
	{
		if(userName.equals("rahulkrishna") && Password.equals("r@123"))
		{
			return "Success";
		}
		else
		{
			return "Fail";
		}
	}
	
	public String userCheckLenght(String userName,String Password)
	{
		if(userName.length()>6)
		{
			return "Success";
		}
		else
		{
			return "Fail";
		}
	}


}
