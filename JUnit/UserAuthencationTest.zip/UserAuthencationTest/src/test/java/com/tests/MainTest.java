package com.tests;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.main.Authencation;

public class MainTest {

	@Test
	public void testUser()
	{
		Authencation au = new Authencation();
		String test = au.userCheck("rahulkrishna", "r@123");
		assertEquals(test,"Success");
	}
	@Test
	public void testUserNameLength()
	{
		Authencation au = new Authencation();
		String test = au.userCheckLenght("rahulkrishna", "r@123");
		assertEquals(test,"Success");
	}
	@Test
	public void testUserName()
	{
		Authencation au = new Authencation();
		assertNotNull(au);
	}
}
