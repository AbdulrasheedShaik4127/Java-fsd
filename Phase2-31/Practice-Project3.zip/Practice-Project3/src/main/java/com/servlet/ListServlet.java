package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.connect.HibernateUtil;
import com.entity.Eproducts;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ListServlet
 */
@WebServlet("/ListServlet")
public class ListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public ListServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        SessionFactory factory = HibernateUtil.getSessionFactory();
        response.setContentType("text/html");
        Session session = factory.openSession();
        // using HQL
        TypedQuery tq = session.createQuery("from Eproducts");
        
        List<Eproducts> list = tq.getResultList();
        
        session.close();
        
         PrintWriter out = response.getWriter();
         
         out.print("<html><body>");
         out.print("<b>Product Listing</b><br>");
         out.print("<table width=100px border=1>");
         for(Eproducts p: list) {
                out.print("<tr>");
                out.print("<td>"+p.getID()+"</td>");
                out.print("<td>"+p.getName()+"</td>");
                out.print("<td>"+p.getPrice()+"</td>");
                out.print("<td>"+p.getDate_added()+"</td>");
                out.print("</tr>");
         }
         out.print("</table>");
         out.println("</body></html>");

	}

}
