package com.connect;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil
{




public static SessionFactory getSessionFactory() {
	Configuration cnf = new Configuration();
	cnf.configure("hibernate.cfg.xml");
	SessionFactory sessionFactory = cnf.buildSessionFactory();
    return sessionFactory;
}
}
