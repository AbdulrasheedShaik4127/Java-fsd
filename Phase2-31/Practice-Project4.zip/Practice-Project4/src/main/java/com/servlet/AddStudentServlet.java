package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;



import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddStudentServlet
 */
@WebServlet("/AddStudentServlet")
public class AddStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public AddStudentServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Configuration cnf = new Configuration();
		PrintWriter pw = response.getWriter();
		cnf.configure("hibernate.cfg.xml");
		SessionFactory sf = cnf.buildSessionFactory();
		Session session = sf.openSession();
		Transaction txs = session.beginTransaction();
		
		pw.println("Hibernate Session begins");
		pw.println("Details added Successfully");
		txs.commit();
		sf.close();
		session.close();
		pw.print("Hibernate session closed");
		
	}

}
