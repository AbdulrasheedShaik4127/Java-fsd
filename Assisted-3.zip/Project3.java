package com.projectassited3;

import java.util.Scanner;

public class Project3 {
public static void main(String[] args) {
	Scanner s = new Scanner(System.in);
	int[] arr =new int[] {3,7,2,5,8,9};
	int sum=0;
	System.out.println("Enter the start index");
	int start=s.nextInt();
	System.out.println("Enter the end index ");
	int end = s.nextInt();
	for(int i=start;i<=end-1;i++)
	{
		sum+=arr[i];
	}
	System.out.println("The sum of elements from range "+start+" and "+end+" "+sum);
}
}
