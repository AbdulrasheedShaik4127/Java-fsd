package com.projectassited3;

public class Project1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] arr = new int[] {1,2,3,4,5,6,7,8,9};
		RotateArray ar = new RotateArray();
		ar.rotate(arr, 5);
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]+" ");
		}
		

	}

}
class RotateArray
{
	public void rotate(int[] n,int size)
	{
		if(size>n.length)
		{
			size = size%n.length;
		}
		int[] result =new int[n.length];
		for(int i=0;i<size;i++)
		{
			result[i]=n[n.length-size+i];
		}
		int j=0;
		for(int i=size;i<n.length;i++)
		{
			result[i]=n[j];
			j++;
		}
		System.arraycopy( result, 0, n, 0, n.length );
	}
}
