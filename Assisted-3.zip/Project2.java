package com.projectassited3;

import java.util.Arrays;

public class Project2 {
public static void main(String[] args) {
	int[] arr = new int[] {12, 3, 5, 7, 4, 19, 26};
	System.out.println("fourth Smallest Element is "+smallestElement(arr,4));
	
}
	public static int smallestElement(int[] arr,int element)
	{
		Arrays.sort(arr);
		return arr[element-1];
	}
	
	
	

}
