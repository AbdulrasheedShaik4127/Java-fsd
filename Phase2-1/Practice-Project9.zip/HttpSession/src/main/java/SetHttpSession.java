

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class SetHttpSession
 */
@WebServlet("/SetHttpSession")
public class SetHttpSession extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public SetHttpSession() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username=request.getParameter("username");
		String password = request.getParameter("password");
		HttpSession hs =request.getSession();
		hs.setAttribute("username", username);
		hs.setAttribute("password", password);
		PrintWriter pw = response.getWriter();
		pw.print("<html><body>");
		pw.print("Added to session click next to see details");
		pw.print("<a href=GetHttpSession>Next</a>");
		pw.print("</body></html>");
		
	}

}
