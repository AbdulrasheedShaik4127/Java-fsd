

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class GetHttpSession
 */
@WebServlet("/GetHttpSession")
public class GetHttpSession extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public GetHttpSession() {
        // TODO Auto-generated constructor stub
    }

    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
    	HttpSession hs =request.getSession();
		String username=(String)hs.getAttribute("username");
		String password =(String)hs.getAttribute("password");
		PrintWriter pw = response.getWriter();
		pw.print("<html><body>");
		if(!username.equals("null"))
		{
			pw.print("<h1> UserName: "+username+"</h1>");
		}
		if(!password.equals("null"))
		{
			pw.print("<h1> Password: "+password+"</h1>");
		}
		
		
		pw.print("Session id is"+hs.getId()+"<br>");
		pw.print("Session Created Time"+hs.getCreationTime()+"<br>");
		pw.print("Session Last Accessed time is"+hs.getLastAccessedTime());
		
		pw.print("</body></html>");
		
	}


}
