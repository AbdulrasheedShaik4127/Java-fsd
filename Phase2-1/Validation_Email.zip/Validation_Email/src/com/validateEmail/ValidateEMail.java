package com.validateEmail;

import java.util.ArrayList;
import java.util.Scanner;

public class ValidateEMail {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> al =new ArrayList<String>();
		al.add("abc@gmail.com");
		al.add("xyz@gmail.com");
		al.add("def@gmail.com");
		al.add("ghi@gmail.com");
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the Email id");
		String email =s.nextLine().toLowerCase().trim();
		if(al.contains(email))
		{
			System.out.println("Email is found ");
		}
		else
		{
			System.out.println("Email id not found");
		}
		s.close();
	}

}
