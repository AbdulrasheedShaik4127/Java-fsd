

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GetUrl
 */
@WebServlet("/GetUrl")
public class GetUrl extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public GetUrl() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
    	String bike = request.getParameter("bike");
		String bus = request.getParameter("bus");
		String car = request.getParameter("car");
		String train=request.getParameter("train");
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		pw.print("<html><body>");
		pw.print("Selected Mode Of Transport<br>");
		if(!bike.equals("null"))
		{
			pw.print(bike+"<br>");
		}
		if(!car.equals("null"))
		{
			pw.print(car+"<br>");
		}
		if(!bus.equals("null"))
		{
			pw.print(bus+"<br>");
		}
		if(!train.equals("null"))
		{
			pw.print(train+"<br>");
		}
		pw.print("</body></html>");
		
    }

}
