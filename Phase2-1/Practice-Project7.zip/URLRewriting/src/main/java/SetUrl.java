

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SetUrl
 */
@WebServlet("/SetUrl")
public class SetUrl extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public SetUrl() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String bike = request.getParameter("bike");
		String bus = request.getParameter("bus");
		String car = request.getParameter("car");
		String train=request.getParameter("train");
		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		pw.print("<html><body>");
		pw.print("Your Selected Mode<br> ");
		pw.print("<a href=GetUrl?bike="+bike+"&car="+car+"&bus="+bus+"&train="+train+">Next</a>");
		pw.print("</body></html>");
		
		
	}

}
