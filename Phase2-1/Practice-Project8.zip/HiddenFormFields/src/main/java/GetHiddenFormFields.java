

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GetHiddenFormFields
 */
@WebServlet("/GetHiddenFormFields")
public class GetHiddenFormFields extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public GetHiddenFormFields() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		PrintWriter pw = response.getWriter();
		pw.print("<html><body>");
		if(!username.equals("null"))
		{
			pw.print("username :"+username+"<br>");
		}
		if(!password.equals("null"))
		{
			pw.print("password :"+password+"<br>");
		}
		pw.print("</body></html>");
	}

}
