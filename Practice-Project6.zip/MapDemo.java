package com.collectionsMap;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.TreeMap;

public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashMap<Integer,Integer> m = new HashMap<Integer,Integer>(); 
		
		  m.put(1, 5);
		  m.put(2, 15);
		  m.put(3, 25);
		  m.put(4, 35);
		  m.put(5, 45);
		 

		System.out.println(m);
		System.out.println(m.get(5));
		System.out.println(m.remove(5));
		System.out.println("Size "+m.size());
		
//		LinkedHashMap
		LinkedHashMap<Integer,Integer> lhm = new LinkedHashMap<Integer,Integer>();
		lhm.put(1,4);
		lhm.put(2,4);
		lhm.put(3,4);
		lhm.put(4,4);
		lhm.put(5,4);
		System.out.println(lhm);
		System.out.println(lhm.size());
		
//		TreeMap
		TreeMap<Integer,Integer> lhm1 = new TreeMap<Integer,Integer>();
		lhm1.put(1,6);
		lhm1.put(2,5);
		lhm1.put(3,4);
		lhm1.put(4,8);
		lhm1.put(5,6);
		System.out.println(lhm1);
		System.out.println(lhm1.size());
		


	}

}