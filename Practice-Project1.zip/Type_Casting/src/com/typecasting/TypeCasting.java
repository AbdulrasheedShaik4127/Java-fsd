package com.typecasting;

public class TypeCasting {
	
public static void main(String[] args) {
//implict typecasting
//byte-->char-->short-->int-->long-->float-->double
		char c='d';
		int i=c;
		System.out.println("----Implicit TypeCasting----");
		System.out.println("char to int "+i);
		long l = i;
		System.out.println("int to long "+l);
		float f = l;
		System.out.println("long to float "+f);
		double d =f;
		System.out.println("float to double "+d);
		System.out.println();
		System.out.println("----Explicit typeCasting----");
		System.out.println();
		double d1 =10.85;
		float f1 =(float)d1;
		System.out.println("double to float "+f1);
		long g = (long)f1;
		System.out.println("float to long "+g);
		int i1 = (int)g;
		System.out.println("long to int "+i1);
		short s = (short)i1;
		System.out.println("int to short "+s);
		byte b1 = (byte)s;
		System.out.println("short to byte "+b1);
		System.out.println();
		
		
	
	
}
}
