package com.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ConnectionDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String url="jdbc:mysql://localhost:3306/browser";
		String user_name = "root";
		String pwd = "Rasheed7711@";
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			Connection con = DriverManager.getConnection(url,user_name,pwd);
			Statement stmt = con.createStatement();
			if(con!=null)
			{
				
				//stmt.execute("create table users(user_name varchar(20),pwd varchar(20));");
				System.out.println("Table created Successfully");
			}
			stmt.executeUpdate("insert into users values('rahul','Krishna')");
			System.out.println("One record inserted successfully ");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
