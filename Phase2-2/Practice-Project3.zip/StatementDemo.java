package com.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class StatementDemo {
public static void main(String[] args) {
	Connection con;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/books", "root", "Rasheed7711@");
		if(con!=null)
		{
			Statement stmt = con.createStatement();
			//used to execute static sql queries
			ResultSet rs = stmt.executeQuery("select * from books");
			ResultSetMetaData rd = rs.getMetaData();
			int n = rd.getColumnCount();
			for(int i=1;i<=n;i++)
			{
				System.out.print(rd.getColumnName(i)+"\t\t");
			}
			while(rs.next())
			{
				System.out.print(rs.getInt(1)+"\t");
				System.out.print(rs.getString(2)+"\t\t");
				System.out.print(rs.getString(3)+"\t\t");
				System.out.print(rs.getString(4)+"\t\t");
				System.out.print(rs.getInt(5)+"\t");
				System.out.print(rs.getInt(6)+"\t");
				System.out.println(rs.getInt(7)+"\t");
				
			}
		}
		else
		{
			System.out.println("Connection Not Established");
		}
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
