package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.connect.DBConnection;
import java.sql.ResultSetMetaData;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ProductDetails
 */
public class ProductDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductDetails() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con=DBConnection.getConnection();
		PrintWriter pw = response.getWriter();
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from eproduct");
			ResultSetMetaData rd = rs.getMetaData();
			int n=rd.getColumnCount();
			pw.print("<table width=100% border=1>");
			pw.print("<tr>");
			for(int i=1;i<=n;i++)
			{
				pw.print("<th>"+rd.getColumnName(i)+"</th>");
			}
			pw.print("</tr>");
			while(rs.next())
			{
				pw.print("<tr>");
				pw.print("<td>"+rs.getInt(1)+"</td>");
				pw.print("<td>"+rs.getString(2)+"</td>");
				//pw.print("<td>"+rs.getString(3)+"</td>");
				pw.print("<td>"+rs.getDouble(3)+"</td>");
				pw.print("<td>"+rs.getString(4)+"</td>");
//				pw.print("<td>"+rs.getInt(5)+"</td>");
//				pw.print("<td>"+rs.getInt(6)+"</td>");
//				pw.print("<td>"+rs.getInt(7)+"</td>");
				pw.print("</tr>");
			}
			pw.print("</table>");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
