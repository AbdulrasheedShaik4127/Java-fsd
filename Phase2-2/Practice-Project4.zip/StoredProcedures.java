package com.database;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;



public class StoredProcedures {

	public static void main(String[] args) {
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/books","root","Rasheed7711@");
		CallableStatement cstmt = con.prepareCall("{call InsertPro()}");
		ResultSet rs = cstmt.executeQuery();
		while(rs.next())
		{
			System.out.print(rs.getInt(1)+"\t");
			System.out.print(rs.getString(2)+"\t\t");
			System.out.print(rs.getString(3)+"\t\t");
			System.out.print(rs.getString(4)+"\t\t");
			System.out.print(rs.getInt(5)+"\t");
			System.out.print(rs.getInt(6)+"\t");
			System.out.println(rs.getInt(7)+"\t");
		}
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	

	}

}
