package com.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class CRUDOperations {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/books", "root", "Rasheed7711@");
			while(true)
			{
			System.out.println("1.insert\n2.update\n3.delete");
			PreparedStatement pstmt=null;
			System.out.println("Enter your choice");
			int choice=s.nextInt();
			switch(choice)
			{
			case 1:
				 pstmt = con.prepareStatement("insert into books values(?,?,?,?,?,?,?)");
				System.out.println("Enter the book Id");
				int book_id=s.nextInt();
				System.out.println("Enter the title");
				s.nextLine();
				String title=s.nextLine();
				System.out.println("Enter the Author First Name");
				String a_fname=s.nextLine();
				System.out.println("Enter the Author Last Name");
				String a_lname=s.nextLine();
				System.out.println("Enter the book released year");
				int released_year=s.nextInt();
				System.out.println("Enter the stock Quantity");
				int Stock=s.nextInt();
				System.out.println("Enter the book pages");
				int pages=s.nextInt();
				pstmt.setInt(1, book_id);
				pstmt.setString(2, title);
				pstmt.setString(3, a_fname);
				pstmt.setString(4, a_lname);
				pstmt.setInt(5, released_year);
				pstmt.setInt(6, Stock);
				pstmt.setInt(7, pages);
				pstmt.executeUpdate();
				break;
			case 2:
				System.out.println("Enter the id to which we have to update");
				int id=s.nextInt();
				System.out.println("1.title\n2.author_fname\n3.author_lname\n4.released year\n5.stock_quantity\n6.pages");
				switch(s.nextInt())
				{
				case 1:
					System.out.println("Enter the title");
					String t = s.next();
					pstmt =con.prepareStatement("update books set title =? where id=?");
					pstmt.setString(1, t);
					pstmt.setInt(2, id);
					pstmt.executeUpdate();
					System.out.println("Books table is updated");
					break;
				case 2:
					System.out.println("Enter the author first name");
					String afname = s.next();
					pstmt =con.prepareStatement("update books set author_fname =? where id=?");
					pstmt.setString(1, afname);
					pstmt.setInt(2, id);
					pstmt.executeUpdate();
					System.out.println("Books table is updated");
					break;
				case 3:
					System.out.println("Enter the author last name");
					String alname = s.next();
					pstmt =con.prepareStatement("update books set author_lname =? where id=?");
					pstmt.setString(1, alname);
					pstmt.setInt(2, id);
					pstmt.executeUpdate();
					System.out.println("Books table is updated");
					break;
				case 4:
					System.out.println("Enter the released year");
					int ryear = s.nextInt();
					pstmt =con.prepareStatement("update books set released_year =? where id=?");
					pstmt.setInt(1, ryear);
					pstmt.setInt(2, id);
					pstmt.executeUpdate();
					System.out.println("Books table is updated");
					break;
				case 5:
					System.out.println("Enter the stock quantity");
					int stock = s.nextInt();
					pstmt =con.prepareStatement("update books set stock_quantity =? where id=?");
					pstmt.setInt(1, stock);
					pstmt.setInt(2, id);
					pstmt.executeUpdate();
					System.out.println("Books table is updated");
					break;
				case 6:
					System.out.println("Enter the pages");
					int page = s.nextInt();
					pstmt =con.prepareStatement("update books set pages =? where book_id=?");
					pstmt.setInt(1, page);
					pstmt.setInt(2, id);
					pstmt.executeUpdate();
					System.out.println("Books table is updated");
					break;
				default:
					System.out.println("Invalid choice");
					break;
				}
				break;
			case 3:
				System.out.println("Enter the book_id to delete");
				int id1=s.nextInt();
				pstmt = con.prepareStatement("select book_id from books where book_id=?");
				pstmt.setInt(1, id1);
				ResultSet rs = pstmt.executeQuery();
				if(rs.next())
				{
				pstmt=con.prepareStatement("delete from books where book_id = ?");
				pstmt.setInt(1, id1);
				pstmt.executeUpdate();
				System.out.println("Element with id "+id1 + " is deleted");
				}
				else
					System.out.println("No element is found");
				break;
			}
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
