package com.update;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.connect.DBConnection;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class UpdateCheck
 */
public class UpdateCheck extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateCheck() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con=DBConnection.getConnection();
		PrintWriter pw = response.getWriter();
		int i=Integer.parseInt(request.getParameter("id"));
		try {
			PreparedStatement pstmt =con.prepareStatement("select id from eproduct where id=?");
			pstmt.setInt(1,i);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
			{
				String name=request.getParameter("name");
				double d = Double.parseDouble(request.getParameter("price"));
				PreparedStatement stmt = con.prepareStatement("update eproduct set name=? and price=? where ID=?");
				stmt.setString(1, name);
				stmt.setDouble(2, d);
				stmt.setInt(3, i);
				stmt.executeUpdate();
				pw.print("One recored updated");
				RequestDispatcher rd= request.getRequestDispatcher("index.html");
				rd.include(request, response);
			}
			else
			{
				pw.print("No details Found");
				RequestDispatcher rd= request.getRequestDispatcher("index.html");
				rd.include(request, response);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
