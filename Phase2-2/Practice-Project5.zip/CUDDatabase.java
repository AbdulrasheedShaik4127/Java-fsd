package com.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CUDDatabase {

	public static void main(String[] args) {
		//Creating database
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/", "root", "Rasheed7711@");
			Statement stmt = con.createStatement();
			stmt.execute("create database DemoMp");
			System.out.println("Database Created Successfully");
			stmt.execute("use DemoMp");
			System.out.println("DemoMp is in use");
			stmt.execute("drop database DemoMp");
			System.out.println("Database Demomp dropped");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
