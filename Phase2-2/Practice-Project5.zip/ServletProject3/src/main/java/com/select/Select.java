package com.select;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.connect.DBConnection;

/**
 * Servlet implementation class Select
 */
public class Select extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Select() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con=DBConnection.getConnection();
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String databasename=null;
		try {
			ResultSet resultSet = con.getMetaData().getCatalogs();
			String dbName=request.getParameter("dbname");
			boolean status=false;
			while(resultSet.next())
			{
				databasename = resultSet.getString(1);
				if(databasename.equals(dbName))
					{
					status=true;
					}
			}
		    
		    if(status)
		    {
			Statement stmt = con.createStatement();
			stmt.execute("use "+dbName);
			pw.print(dbName+" Database using");
			RequestDispatcher rd = request.getRequestDispatcher("index.html");
			rd.include(request, response);
		    }
		    else
		    {
		    	pw.print("Database doesn't  Exists");
		    	RequestDispatcher rd = request.getRequestDispatcher("index.html");
				rd.include(request, response);
		    	
		    }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
