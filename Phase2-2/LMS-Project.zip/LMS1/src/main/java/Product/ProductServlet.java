package Product;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import Connect.DbConnection;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ProductServlet
 */
public class ProductServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PreparedStatement pstmt =null;
	ResultSet rs=null;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProductServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		try
		{
		Connection con=DbConnection.getConnection();
		PrintWriter pw = response.getWriter();
		pstmt=con.prepareStatement("select ID from eproduct where ID=?");
		int id=Integer.parseInt(request.getParameter("id"));
		pstmt.setInt(1, id);
		 rs= pstmt.executeQuery();
		
		if(rs.next())
		{
			pstmt=con.prepareStatement("select * from eproduct where id=?");
//		int id=Integer.parseInt(request.getParameter("id"));
			pstmt.setInt(1, id);
		
			rs = pstmt.executeQuery();
			ResultSetMetaData rd = rs.getMetaData();
			int n = rd.getColumnCount(); 
			pw.print("<table width='100%' border='1'>");
			pw.print("<tr>"); 
		   for(int i=1;i<=n;i++) 
		   { 
		  pw.print("<th>"+rd.getColumnName(i)+"</th>"); 
		  }
		    pw.print("</tr>");
		 	while(rs.next())
		 {
			pw.print("<tr>");
			pw.print("<td>"+rs.getInt("ID")+"</td>");
			pw.print("<td>"+rs.getString("name")+"</td>");
			pw.print("<td>"+rs.getString("price")+"</td>");
			pw.print("<td>"+rs.getString("date_added")+"</td>");
//			pw.print("<td"+rs.getInt("released_year")+"</td>");
//			pw.print("<td"+rs.getInt("stock_quantity")+"</td>");
//			pw.print("<td"+rs.getInt("pages")+"</td>");
			pw.print("</tr>");
		}
		pw.print("</table>");
		}else
			pw.print("<h1>No Elements With"+id+" not Found </h1>");
		}catch(Exception e)
		{
			e.printStackTrace();
		}
	}

}
