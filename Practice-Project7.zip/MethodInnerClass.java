package com.innerclass;

public class MethodInnerClass {

	private  String msg=" Method Inner Classes";
	private int value=200;
	private  static String re="Static varibles";

	 void display(){  
		 class Inner{  
			 void msg(){
				 System.out.println(msg);
				 System.out.println(value);
			 }  
	  }  
	  Inner l=new Inner();  
	  l.msg();  
	 }  
	 
	 static void display1()
	 {
		 class Inner1
		 {
			 static void msg1()
			 {
				 System.out.println(re);
//				 System.out.println(msg);we cannot acces instance from static area
			 }
		 }
		 Inner1.msg1();
	 }

	 
	public static void main(String[] args) {
		MethodInnerClass  ob=new MethodInnerClass();  
		ob.display();  
		ob.display1();
		}
	}



