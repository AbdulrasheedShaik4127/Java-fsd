package com.innerclass;

public class InnerClassesDemo {
	/*
	 * Inner class:-declaring a class inside a class types:- 
	 * Normal
	 * Method Local
	 * Anonymous
	 * static 
	 * 1.Normal:- defining a class inside a class without a static
	 * modifier
	 */
//	Normal
	int x=20;
	static int y=30;
	class Inner
	{
	public void welcome()
	{
		System.out.println(x);
		System.out.println(y);
		InnerClassesDemo o = new InnerClassesDemo();
		o.Welcome1();
		System.out.println("Welcome to inner classes");
	}
	class Inner1
	{
		int x=30;
	}
	}
public void Welcome1()
{
	Inner i = new Inner();
	//i.welcome();
	System.out.println("Outer class Demo");
}
public static void main(String[] args) {
	
	InnerClassesDemo icd = new InnerClassesDemo();
	InnerClassesDemo.Inner i = icd.new Inner();
	InnerClassesDemo.Inner.Inner1 i1 = i.new Inner1();
	i.welcome();
	System.out.println(i1.x);
	//new InnerClassesDemo().new Inner().welcome();
	int x1 =new InnerClassesDemo().new Inner().new Inner1().x;
	System.out.println(x1);
	
	
}
}


