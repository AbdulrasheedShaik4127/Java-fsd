package com.innerclass;

public class AnonymousInnerClass {
	
	public static void main(String[] args) {
		
		PopCorn aic = new PopCorn()
		{
		 public void taste()
		 {
			 System.out.println("salty");
		 }
		};
		aic.taste();
		PopCorn p = new PopCorn();
		p.taste();
	}
	   
}
class PopCorn
{
	public void taste()
	{
		System.out.println("spicy");
	}
}







