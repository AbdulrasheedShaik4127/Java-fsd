package com.calci;

import java.util.Scanner;

public class Calculator {
public static void main(String[] args) {
	//reading operands from user
	Scanner s = new Scanner(System.in);
	System.out.println("Enter the first number");
	int num1=s.nextInt();
	System.out.println("Enter the second number");
	int num2=s.nextInt();
	System.out.println("Select the option as (1/2/3/4/5/6):\n1.Addition\n2.Subtraction\n3.Multiplication\n4.Division\n5.Modulo\n6.Exit");
	switch(s.nextInt())
	{
	case 1: System.out.println("Addition is "+(num1+num2));
			break;
	case 2: System.out.println("Subtraction is "+(num1-num2));
			break;
	case 3: System.out.println("Multiplication is "+(num1*num2));
			break;
	case 4: System.out.println("Division is "+(num1/num2));
			break;
	case 5: System.out.println("Modulo is "+(num1%num2));
			break;
	case 6:System.out.println("Cancelled Operation"); 
		   System.exit(0);
		   break;
	default:System.out.println("Invalid choice");
			break;
	
	}
	s.close();
}
}
