package com.defaultaccess;

public class DefaultAccessModifier {
	//Default Access Modifier --> scope within the package
	void display()
	{
		System.out.println("Default Access Modidier");
	}
}
