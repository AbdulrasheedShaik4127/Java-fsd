package com.defaultaccess;

public class AccessModifiers {

	public static void main(String[] args) {
		/* Access Modifiers
		  1.default
		  2.public
		  3.private
		  4.protected
		*/
		//creating object for DefaultAccessModifier class
		DefaultAccessModifier def = new DefaultAccessModifier();
		def.display();
		

	}

}
