package com.publicaccess;

public class PublicAccessModifier {
public void display()
{
	System.out.println("****----public access modifier----****");
	String name="welcome";
	String location="hyderabad";
	System.out.println(name+" to "+location);
}
}
