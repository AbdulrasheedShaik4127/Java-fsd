package com.publicaccess;

public class AccessModifier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//public --> we can access anywhere in project
		PublicAccessModifier pam = new PublicAccessModifier();
		pam.display();
	}

}
