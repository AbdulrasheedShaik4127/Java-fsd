package com.privateaccess;

public class PrivateAccessModifier {
//private access modifier --> with in the same class only
	private void display()
	{
		System.out.println("****----Private Access Modifier Demo----****");
		int a=10;
		int b=20;
		System.out.println((a%10)+(b%10));
	}
}
