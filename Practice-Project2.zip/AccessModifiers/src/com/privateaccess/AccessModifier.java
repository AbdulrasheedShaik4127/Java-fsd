package com.privateaccess;

public class AccessModifier {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//creating object for PrivateAccessModifier class
		PrivateAccessModifier pam = new PrivateAccessModifier();
		//pam.display();//we cannot access display method having private access modifier from another class
	}

}
