import { Component } from '@angular/core';
import { UserService } from '../user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../user';

@Component({
  selector: 'app-view-details',
  templateUrl: './view-details.component.html',
  styleUrls: ['./view-details.component.css']
})
export class ViewDetailsComponent {
  ngOnInit():void
  {
    this.id=this.route.snapshot.params['id'];
    console.log(this.id);
    this.ViewDetails();
  }
  constructor(private service:UserService,private route:ActivatedRoute,private router:Router)
  {

  }
  
  
  user:User;
  
 id:number;
  ViewDetails()
  {
    this.service.getDetails(this.id).subscribe(data=>
      {
          this.user=data;
      })
  }
  logout()
  {
    this.router.navigate(['/login']);
  }

}
