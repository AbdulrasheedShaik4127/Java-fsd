import { Component } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';
import { Router } from '@angular/router';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent {

  user:User = new User();
  constructor(private service:UserService,private route:Router)
  {

  }
  registerUser()
  {
    this.service.addUser(this.user).subscribe(data=>
      {
        
        alert("Application is submitted");
        this.route.navigate(['/login']);
      });
  }

}
