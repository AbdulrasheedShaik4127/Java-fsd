import { Component } from '@angular/core';
import { LoginService } from '../login.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { User } from '../user';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  id:number;
  siginin:FormGroup;
  emailId:string;
  password:string;
  msg:string;
  check:User;
  constructor(private service:LoginService,private router:Router,private http:HttpClient)
  {
    this.siginin = new FormGroup({
      personEmail:new FormControl("",[Validators.required]),
      personPassword:new FormControl("",[Validators.required])
    }
    )
  }
  

  LoginCheck()
  {
    this.service.userLogin(this.emailId,this.password).subscribe(data=>{
      this.check=data;
      
      console.log(this.check);
      if(this.check!=null)
      {
        this.id=this.check.id;
        this.router.navigate(['user/details/'+`${this.id}`]);
        console.log(this.id);
      }
      else{
        this.msg="Invalid username or password";
      }
    })
  }

}
