import { Component, DoCheck } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements DoCheck {
  title = 'EAadharApplication';
  menu1:boolean=false;
  constructor(private router:Router)
  {

  }

  ngDoCheck():void{
    let currentroute=this.router.url;
    if(currentroute=="/")
    {
      this.menu1=true;
    }
    else{
      this.menu1=false;
    }
  }
  ngOnInit() {
    document.body.className = "selector";
  }

ngOnDestroy(){
    document.body.className="";
  }
}
