import { Component } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-approve',
  templateUrl: './approve.component.html',
  styleUrls: ['./approve.component.css']
})
export class ApproveComponent {
  id:number;
  check:boolean;
  constructor(private service:UserService,private route:ActivatedRoute,private router:Router)
  {

  }
user:User=new User();
ngOnInit():void{
  this.id=this.route.snapshot.params['id'];
  this.service.getDetails(this.id).subscribe(data=>
    {
      this.user=data;
    })
}
updateApprove()
{
  this.service.updateUserBasedOnId(this.id,this.user).subscribe(data=>
    {
      if(data)
      {
        this.service.getAllDetails();
        this.router.navigate(['/user/viewall'])
      }

    })
}
}
