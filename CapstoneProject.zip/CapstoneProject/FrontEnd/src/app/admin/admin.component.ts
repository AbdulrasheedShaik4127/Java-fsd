import { Component } from '@angular/core';
import { LoginService } from '../login.service';
import { HttpClient } from '@angular/common/http';
import { Admin } from '../admin';
import { Router, Routes } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent {
  emailId:string;
  password:string;
  admin:boolean;
  msg:string;
  constructor(private service:LoginService,private route:Router)
  {}

  AdminLogin()
  {
    this.service.adminLogin(this.emailId,this.password).subscribe(data=>
      {
        this.admin=data;
        if(this.admin==true)
        {
          this.route.navigate(['user/viewall']);
        }
        else{
          this.msg="Invalid username or password";
        }
      })
  }

}
