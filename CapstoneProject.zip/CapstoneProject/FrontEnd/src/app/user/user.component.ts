import { Component } from '@angular/core';
import { User } from '../user';
import { UserService } from '../user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent {
  constructor(private service:UserService,private router:Router)
  {}
  user:User[];
  msg:string;

  ngOnInit():void{
    this.getAllDetails();
  }
  getAllDetails()
  {
    this.service.getAllDetails().subscribe(data=>
      {
        this.user=data;
      })
  }
  deleteUserById(id:any)
  {
    if(confirm("Are you sure you want to delete"))
    {
      this.service.deleteUser(id).subscribe(data=>
        {
          this.getAllDetails();
        });
    }
  }
  logout()
  {
    this.router.navigate(['/']);
  }
  approveSwitch(id:any)
  {
    this.router.navigate(['approve',id]);
  }

}
