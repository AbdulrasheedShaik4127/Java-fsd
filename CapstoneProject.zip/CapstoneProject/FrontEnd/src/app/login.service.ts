import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {Observable} from 'rxjs'
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  private url="http://localhost:8585/user/login"
  private adminurl="http://localhost:8585/admin/login"
  constructor(private http:HttpClient) { }

  userLogin(emailId:string,password:string):Observable<User>
  {
    return this.http.get<User>(`${this.url}/${emailId}/${password}`);
  }
  adminLogin(emailId:string,password:string):Observable<boolean>
  {
    console.log()
    return this.http.get<boolean>(`${this.adminurl}/${emailId}/${password}`);
  }
  
}
