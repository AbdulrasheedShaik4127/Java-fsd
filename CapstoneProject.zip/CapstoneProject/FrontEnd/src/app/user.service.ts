import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from './user';
import {Observable } from 'rxjs'

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }
  private url="http://localhost:8585/user/";
  private adminurl="http://localhost:8585/users/";
  userLogin():Observable<User>
  {
    return this.http.get<User>(`${this.url}`);
  }
  getDetails(id:any):Observable<User>
  {
    return this.http.get<User>(`${this.url}details/${id}`);
  }
  getAllDetails():Observable<User[]>
  {
    return this.http.get<User[]>(`${this.adminurl}viewall`)
  }
  addUser(user:User):Observable<Object>
  {
    return this.http.post(`${this.url}register`,user);
  }
  deleteUser(id:number):Observable<string>
  {
    return this.http.delete<string>(`${this.url}delete/${id}`);
  }
  updateUserBasedOnId(id:number,user:User):Observable<boolean>
  {
     return this.http.put<boolean>(`${this.url}update/${id}`,user);
  }
}
