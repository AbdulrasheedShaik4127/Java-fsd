export class User {
    id:number;
    name:string;
    aadharNo:number;
    emailId:string;
    dob:any;
    address:string;
    mobileNo:string;
    gender:string;
    password:string

}
