export class Admin {
    emailId:string;
    password:string
}
