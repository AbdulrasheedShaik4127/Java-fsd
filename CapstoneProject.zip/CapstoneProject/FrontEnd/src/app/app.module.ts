import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdminComponent } from './admin/admin.component';
import { UserComponent } from './user/user.component';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http'
import { RouterModule } from '@angular/router';
import { Routes } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LoginComponent } from './login/login.component';
import { ViewDetailsComponent } from './view-details/view-details.component';
import { RegistrationComponent } from './registration/registration.component';
import { UpdateComponent } from './update/update.component';
import { ApproveComponent } from './approve/approve.component';

const routes:Routes=[
  
  {path:"admin",component:AdminComponent},
  {path:"login",component:LoginComponent},
  {path:"newuser",component:RegistrationComponent},
  {path:"user/details/:id",component:ViewDetailsComponent},
  {path:"user/viewall",component:UserComponent},
  {path:"approve/:id",component:ApproveComponent}
  ]
@NgModule({
  declarations: [
    AppComponent,
    AdminComponent,
    UserComponent,
    LoginComponent,
    ViewDetailsComponent,
    RegistrationComponent,
    UpdateComponent,
    ApproveComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    [RouterModule.forRoot(routes),
    NgbModule
  ]
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
