package com.testing;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class Application {
	
	WebDriver driver = new ChromeDriver();
	
	@Test
	public void UserLogin() throws InterruptedException
	{
		driver.get("http://localhost:4200/");
		 driver.findElement(By.xpath("/html/body/app-root/html/body/div[2]/div[1]/div[2]/div/div/a[2]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.name("emailId")).sendKeys("r@gmail.com");
		 driver.findElement(By.name("password")).sendKeys("r@gmail.com");
		 driver.findElement(By.xpath("/html/body/app-root/app-admin/div/div/div[2]/div/div[2]/form/div/button")).click();
		 
	}
	@Test
	public void AdminLogin() throws InterruptedException
	{
		 driver.get("http://localhost:4200/");
		 driver.findElement(By.xpath("/html/body/app-root/html/body/div[2]/div[1]/div[2]/div/div/a[1]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.name("emailId")).sendKeys("r@gmail.com");
		 driver.findElement(By.name("password")).sendKeys("r@gmail.com");
		 driver.findElement(By.xpath("/html/body/app-root/app-login/div/div/div[2]/div/div[2]/form/div/button")).click();
		 
	}
}
