package com.searching;

import java.util.Scanner;

public class BinarySearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] x = new int[] {45,48,52,75,16};
		System.out.println("Enter value to search");
		Scanner sc = new Scanner(System.in);
		int key = sc.nextInt();
		int first = 0;
		int last = x.length-1;
		int mid = (first+last)/2;
		boolean b = false;
		while(first<=last)
		{
			if(x[mid]==key)
			{
				System.out.println("Value Found...");
				b = true;
				break;
			}
			else if(x[mid]<key)
			{
				first = mid+1;
			}
			else if(x[mid]>key)
			{
				last = mid-1;
			}
			mid = (first+last)/2;
		}
		
		if(b ==false)
			System.out.println("Value not Found");

	}

}
