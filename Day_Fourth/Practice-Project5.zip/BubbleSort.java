package com.searching;

public class BubbleSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x = new int[] {1,8,5,6,9,0,-1};
		for(int i=0;i<x.length;i++)
		{
			for(int j=0;j<x.length-i-1;j++)
			{
				if(x[j]>x[j+1])
				{
					int temp = x[j];
					x[j]=x[j+1];
					x[j+1]=temp;
				}
			}
		}
		System.out.println("The array of BubbleSort is :");
		for(int i=0;i<x.length;i++)
		{
			System.out.println(x[i]+" ");
		}

	}

}
