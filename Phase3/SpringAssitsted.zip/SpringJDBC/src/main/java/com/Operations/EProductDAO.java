package com.Operations;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.BeanPropertyRowMapper;

import com.entities.EProducts;

public class EProductDAO {
JdbcTemplate template;
public void setTemplate(JdbcTemplate template) {    
    this.template = template;    
} 

public String addEprodct(EProducts product)
{
	String res ="Err";
	String query ="insert into EProducts(id,Name,Price) values (?,?,?)";
	int n = template.update(query,new Object[] {product.getId(),product.getName(),product.getPrice()});
	if(n>1)
	{
		res="Success";
	}
	return res;
}
public List<EProducts> getAllDetails()
{
	List<EProducts> list=template.query("select * from EProducts", new BeanPropertyRowMapper(EProducts.class));
	return list;
}
}
