package com.connect;

import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;

import com.entities.Product;
import com.servlet.ServletGetData;

public class DBConnect {
	public static SessionFactory getSessionFactory()
	{
		Configuration cnf = new Configuration();
		Properties p = new Properties();
		p.put(Environment.DRIVER, "com.mysql.cj.jdbc.Driver");
		p.put(Environment.URL, "jdbc:mysql://localhost:3306/mypractice");
		p.put(Environment.USER, "root");
		p.put(Environment.PASS, "Rasheed7711@");
		p.put(Environment.DIALECT, "org.hibernate.dialect.MySQL5Dialect");
		p.put(Environment.HBM2DDL_AUTO, "update");
		p.put(Environment.SHOW_SQL, true);
		cnf.setProperties(p);
		cnf.addAnnotatedClass(Product.class);
//		cnf.addAnnotatedClass(ServletGetData.class);
		
		SessionFactory sf = cnf.buildSessionFactory();
		return sf;
	}

}
