package com.servlet;

import java.io.IOException;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.connect.DBConnect;
import com.entities.Product;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class ServletGetData
 */
public class ServletGetData extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public ServletGetData() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		SessionFactory sf = DBConnect.getSessionFactory();
		Session s =sf.openSession();
		Transaction txs = s.beginTransaction();
		HttpSession hs = request.getSession();
		int id=Integer.parseInt(request.getParameter("id"));
		String name=request.getParameter("name");
		float f = Float.parseFloat(request.getParameter("price"));
		String date=request.getParameter("date");
		Product p = new Product();
		p.setId(id);
		p.setName(name);
		p.setPrice(f);
		p.setDoa(date);
		s.save(p);
		txs.commit();
		hs.setAttribute("id", id);
		hs.setAttribute("name", name);
		hs.setAttribute("price", f);
		hs.setAttribute("date", date);
		response.sendRedirect("Second.jsp");
		sf.close();
		
		
		
		
	}

}
