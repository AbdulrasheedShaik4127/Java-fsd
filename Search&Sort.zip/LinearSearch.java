package com.searching;

import java.util.Scanner;

public class LinearSearch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x = new int[] {4,5,8,6,8};
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the element to found ");
		int data = s.nextInt();
		boolean status=true;
		for(int i=0;i<x.length;i++)
		{
			if(x[i]==data)
			{
				System.out.println("Element Found at "+(i+1)+" Position");
				status=false;
				break;
			}
		}
		if(status)
		{
			System.out.println("Element not found");
		}

	}

}
