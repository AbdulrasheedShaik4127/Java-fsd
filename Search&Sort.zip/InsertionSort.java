package com.searching;

public class InsertionSort {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] x = new int[] {10,3,4,-8,7};
		for(int i=1;i<x.length;i++)
		{
			int temp=x[i];
			int j=i-1;
			while(j>=0 && temp<x[j])
			{
				x[j+1]=x[j];
				j=j-1;
			}
			x[j+1]=temp;
		}
		System.out.println("The array of BubbleSort is :");
		for(int i=0;i<x.length;i++)
		{
			System.out.println(x[i]+" ");
		}

	}

}
